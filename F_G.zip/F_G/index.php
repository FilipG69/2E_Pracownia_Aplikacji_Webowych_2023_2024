<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>skrypt php</title>
</head>
<body>
<p>
<?php
$zmienna1 = 1;
$zmienna2 = 12.43;
$zmienna3 = "abc";
echo $zmienna1 , $zmienna2 , $zmienna3;
?>
 </p>
</body>
</html>