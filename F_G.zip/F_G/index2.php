<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>skrypt php</title>
</head>
<body>
<p>
<?php
$zmienna1 = (string)"ABBAA";
$zmienna2 = (string)"abbca";
$zmienna3 = (string)"abc";
$zmienna4 = (string)"abbc"
$tekst = <<<TX
$zmienna2
TX;
echo $zmienna1;
$tekst2 = <<<'TC'
$zmienna 3
TC;
echo '$zmienna4'
?>
 </p>
</body>
</html>