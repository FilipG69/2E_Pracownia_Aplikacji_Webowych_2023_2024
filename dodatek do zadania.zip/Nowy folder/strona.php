
 <?php
session_start();
 if (!isset($_SESSION['log'])) {
    header('location: loguj.php');
    exit();
}
?>  
<!DOCTYPE html>
<html lang="en">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale-1.0">
<title>Document</title>
<head>
</head>
<body>
<?php
 $imie = ucfirst($_SESSION['log']);
echo "Witaj" . $imie;
?>
<p>Jestes na stronie glownej. </p>
 <a href="wyloguj.php">wyloguj</a>
<p>Przed opuszczeniem strony wyloguj sie!</p>
</body>
</html>