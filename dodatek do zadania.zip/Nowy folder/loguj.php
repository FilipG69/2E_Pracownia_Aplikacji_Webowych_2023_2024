<?php
session_start();
if (isset($_SESSION['log'])) {
    header('location: strona.php');
    exit();
} elseif (isset($_POST['nazwa']) && isset($_POST['haslo'])) {
    if ($_POST['nazwa'] == 'janek' && $_POST['haslo'] == "1234"){
    $_SESSION['log'] = $_POST['nazwa'];
    header('location: strona.php');
    exit();
} else {
    echo "zle haslo";
}
}
?>

    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <style>
            p. fo{
                font-weight: bold;
                font-size :11pt
            }
            #log {
                font-weight: bold;
                font-size :14pt
            }
        </style>
    </head>
    <body>
        <div>
        <form action="http://localhost/loguj.php" method="POST">
            <p id="log">logowanie</p>
            <p class="fo">nazwa uzytkownika </p>
            <input type="text" name="nazwa" valiue="" size="25"> <br />
            <p class="fo">haslo</p>
            <input type="password" name="haslo" valiue="" size="25"> <br />
            <input type="submit"value="zaloguj sie"> 

                
            </form>
</div>


    </body>
    </html>